
<?php
require_once "conexion.php";
 

if ($_POST['action'] == 'buscar') {
    $array['datos'] = array();
    for ($i=0; $i < count($_POST['data']); $i++) { 
        $id = $_POST['data'][$i]['id'];
        $query = mysqli_query($conexion, "SELECT * FROM productos WHERE id = $id");
        $result = mysqli_fetch_assoc($query);
        $data1['id'] = $result['id'];
        $data2['nombre'] = $result['descripcion'];
        $data3['precio'] = $result['precio_rebajado'];

        $insertar= "INSERT INTO detalleproducto VALUES ('','$data1','$data2','$data3')";

        $query=mysqli_query($conexion, $insertar);

        if($query){

            echo' <script>alert("Compra realizada")</script>
        
            ';
            
        }else{
            echo"error";
        }
      
        
    }
    

}
?>