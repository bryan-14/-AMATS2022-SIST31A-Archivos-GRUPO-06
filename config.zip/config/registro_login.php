<?php

require 'conexion.php';
$usuario=$_POST['usuario'];
$gmail=$_POST['gmail'];
$nombre=$_POST['nombre'];
$clave=$_POST['clave'];
$clavedos= md5($clave);
//$clavetres=

$insertar = "INSERT INTO usuarios VALUES ('','$usuario','$gmail','$nombre','$clavedos')";

$query=mysqli_query($conexion, $insertar);
 

if($query){
    
    echo"
    <script>
    location.href='../Login.php';
    </script>
    ";
    
}else{
    echo"error";
}
?>