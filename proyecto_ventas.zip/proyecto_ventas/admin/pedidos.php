<?php include("includes/header.php"); 
require_once "../config/conexion.php";

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Pedidos</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="container">
  <h2>Orden de pedidos</h2>
  <br>
  <div class="table-responsive">
          
  <table class="table table-dark table-hover">
    <thead>
    <tr>
                        <th>Id pedido</th>
                        <th>Producto</th>
                        <th>Fecha</th>
                        <th>Cliente </th>
                        <th>Dirección</th>
                        <th>Gmail</th>
                        <th>Teléfono</th>
                        <th>Estado</th>
                        <th>SubTotal</th>
                       
                        
                        <th></th>
                    </tr>
    </tbody>
    <style>
                    .cont{
                        vertical-align:top;
                        color: #FFF791;
                         text-align:center;
                    }
                </style>
    <?php
$query = mysqli_query($conexion, "SELECT * FROM pedidos");
while ($data = mysqli_fetch_assoc($query)) { ?>
    <tr class="cont">
        
        <td><?php echo $data['id']; ?></td>
        <td><?php echo $data['producto']; ?></td>
        <td><?php echo $data['fecha']; ?></td>
        <td><?php echo $data['nombre']; ?></td>
        <td><?php echo $data['direccion']; ?></td>
        <td><?php echo $data['gmail']; ?></td>
        <td><?php echo $data['telefono']; ?></td>
        <td><?php echo $data['estado']; ?></td>
        <td><?php echo $data['total_pagar']; ?></td>
        <td><?php echo $data['cancelado']; ?></td>
       
    </tr>
<?php } ?>
  </table>
</div>
</div>
</body>
</html>

<?php include("includes/footer.php"); ?>